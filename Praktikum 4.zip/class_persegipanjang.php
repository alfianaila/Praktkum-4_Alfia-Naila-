<?php
class Persegi {
    public $p;
    public $l;

    function __construct($p, $l) {
        $this->p = $p;
        $this->l = $l;
    }
    public function hitungLuas() {
        $luas = $this->p * $this->l;
        return $luas;
    }

    public function hitungKeliling() {
        $keliling = (2 * $this->p) + (2 * $this->l);
        return $keliling;
    }
}
?>