<?php
require_once 'class_persegipanjang.php';

echo Persegi;

echo '<br><br>';

$persegi1 = new Persegi(10,7);
$persegi2 = new Persegi(7,8);

echo "Luas Persegi 1 : " . $persegi1->hitungLuas();
echo '<br>';
echo "Luas Persegi 2 : " . $persegi2->hitungLuas();

echo '<br><br>';

echo "Keliling Persegi 1 : " . $persegi1->hitungKeliling();
echo '<br>';
echo "Keliling Persegi 2 : " . $persegi2->hitungKeliling();
?>